 +-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+
 |D|e|v|i|l|'|s| |W|o|r|k|.|s|h|o|p|
 +-+-+-+-+-+-+-+ +-+-+-+-+-+-+-+-+-+

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Making your first City Builder / Town Builer Game? Or Just a small simulation game with procedural assets? Grab this assets pack for cheap that comes with high quality game assets that are optimized to run on very low end mobile devices, and PC. 

The Devil's Work.shop City Builder Pixel 3D Game Assets is a large collection of Road Blocks, Buildings, Vehicles, City Props, and Trees totaling close to 80, 3D assets.


3D Asset Specifications
Format: FBX, OBJ
Texture: PNG 
Resolution: 1024x1024



::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Features

Free periodic updates
Ready for Unity projects
Please leave a review, If you like these assets, or have a specific art asset need.

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


Ajay Karat | Devil's Work.shop
http://devilswork.shop/

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


If you like this Game Asset Pack, please consider taking a moment to rate/review it. Your continued support helps The Devil's Workshop bring new improvements to the pack!

Ajay Karat
DevilsWork.shop	
help@devilswork.shop

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

http://devilswork.shop/
http://twitter.com/devilswork_shop 



